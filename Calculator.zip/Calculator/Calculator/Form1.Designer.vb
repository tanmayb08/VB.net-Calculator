﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Button12 = New Button()
        Button13 = New Button()
        Button14 = New Button()
        Button15 = New Button()
        Button16 = New Button()
        Button17 = New Button()
        Button18 = New Button()
        TextBox1 = New TextBox()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(12, 124)
        Button1.Name = "Button1"
        Button1.Size = New Size(65, 56)
        Button1.TabIndex = 0
        Button1.Text = "7"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(83, 124)
        Button2.Name = "Button2"
        Button2.Size = New Size(65, 56)
        Button2.TabIndex = 1
        Button2.Text = "8"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(154, 124)
        Button3.Name = "Button3"
        Button3.Size = New Size(65, 56)
        Button3.TabIndex = 2
        Button3.Text = "9"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(12, 186)
        Button4.Name = "Button4"
        Button4.Size = New Size(65, 56)
        Button4.TabIndex = 3
        Button4.Text = "4"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(83, 186)
        Button5.Name = "Button5"
        Button5.Size = New Size(65, 56)
        Button5.TabIndex = 4
        Button5.Text = "5"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(154, 186)
        Button6.Name = "Button6"
        Button6.Size = New Size(65, 56)
        Button6.TabIndex = 5
        Button6.Text = "6"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(12, 250)
        Button7.Name = "Button7"
        Button7.Size = New Size(65, 56)
        Button7.TabIndex = 6
        Button7.Text = "1"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(83, 250)
        Button8.Name = "Button8"
        Button8.Size = New Size(65, 56)
        Button8.TabIndex = 7
        Button8.Text = "2"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(154, 248)
        Button9.Name = "Button9"
        Button9.Size = New Size(65, 56)
        Button9.TabIndex = 8
        Button9.Text = "3"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Location = New Point(12, 312)
        Button10.Name = "Button10"
        Button10.Size = New Size(65, 56)
        Button10.TabIndex = 9
        Button10.Text = "+/-"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Location = New Point(83, 312)
        Button11.Name = "Button11"
        Button11.Size = New Size(65, 56)
        Button11.TabIndex = 10
        Button11.Text = "0"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.Location = New Point(154, 312)
        Button12.Name = "Button12"
        Button12.Size = New Size(65, 56)
        Button12.TabIndex = 11
        Button12.Text = "."
        Button12.UseVisualStyleBackColor = True
        ' 
        ' Button13
        ' 
        Button13.Location = New Point(225, 124)
        Button13.Name = "Button13"
        Button13.Size = New Size(65, 56)
        Button13.TabIndex = 12
        Button13.Text = "+"
        Button13.UseVisualStyleBackColor = True
        ' 
        ' Button14
        ' 
        Button14.Location = New Point(225, 186)
        Button14.Name = "Button14"
        Button14.Size = New Size(65, 56)
        Button14.TabIndex = 13
        Button14.Text = "-"
        Button14.UseVisualStyleBackColor = True
        ' 
        ' Button15
        ' 
        Button15.Location = New Point(225, 248)
        Button15.Name = "Button15"
        Button15.Size = New Size(65, 56)
        Button15.TabIndex = 14
        Button15.Text = "*"
        Button15.UseVisualStyleBackColor = True
        ' 
        ' Button16
        ' 
        Button16.Location = New Point(225, 312)
        Button16.Name = "Button16"
        Button16.Size = New Size(65, 56)
        Button16.TabIndex = 15
        Button16.Text = "/"
        Button16.UseVisualStyleBackColor = True
        ' 
        ' Button17
        ' 
        Button17.Location = New Point(296, 248)
        Button17.Name = "Button17"
        Button17.Size = New Size(72, 120)
        Button17.TabIndex = 16
        Button17.Text = "="
        Button17.UseVisualStyleBackColor = True
        ' 
        ' Button18
        ' 
        Button18.Location = New Point(296, 122)
        Button18.Name = "Button18"
        Button18.Size = New Size(72, 120)
        Button18.TabIndex = 17
        Button18.Text = "C"
        Button18.UseVisualStyleBackColor = True
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Stencil", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox1.Location = New Point(12, 46)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(356, 58)
        TextBox1.TabIndex = 18
        TextBox1.TextAlign = HorizontalAlignment.Right
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Consolas", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(192, 371)
        Label1.Name = "Label1"
        Label1.Size = New Size(183, 18)
        Label1.TabIndex = 19
        Label1.Text = "Made with ❤ by Tanmay"' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(382, 401)
        Controls.Add(Label1)
        Controls.Add(TextBox1)
        Controls.Add(Button18)
        Controls.Add(Button17)
        Controls.Add(Button16)
        Controls.Add(Button15)
        Controls.Add(Button14)
        Controls.Add(Button13)
        Controls.Add(Button12)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Button9)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
End Class
